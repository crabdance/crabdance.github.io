
# p5.dimensions.js
An addon for p5.js which adds support for higher dimensional calculations.

Download the library file [here](https://github.com/Smilebags/p5.dimensions.js/blob/master/libraries/p5.dimensions.js), or read the documentation [here](https://smilebags.github.io/p5.dimensions.js/). 

Or if you don't feel like downloading, just use this embed script tag:
```
<script src="https://raw.githubusercontent.com/Smilebags/p5.dimensions.js/master/libraries/p5.dimensions.js"></script>
```

![Banner](https://cloud.githubusercontent.com/assets/16921177/22859727/b2be42dc-f0b4-11e6-9a3c-f3713054a3ea.jpg "Banner")
